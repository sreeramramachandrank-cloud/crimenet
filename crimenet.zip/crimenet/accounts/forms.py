from django import forms
from .models import User
from officials.models import OfficerProfile, RoleVerification


class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    # 👮 Officer-specific
    rank = forms.ChoiceField(
        choices=OfficerProfile.RANK_CHOICES,
        required=False
    )
    badge_id = forms.CharField(required=False)
    department = forms.CharField(required=False)

    # 🔐 Shared verification fields
    jurisdiction = forms.CharField(required=False)
    appointment_order = forms.FileField(required=False)
    reason_for_access = forms.CharField(
        widget=forms.Textarea,
        required=False
    )
    # 🧬 Forensic Analyst
    lab_affiliation = forms.CharField(required=False)
    forensic_license = forms.FileField(required=False)

    # ⚖️ Judge
    judicial_id = forms.CharField(required=False)
    court_name = forms.CharField(required=False)

    # 🧾 Judicial Auditor
    authority_letter = forms.FileField(required=False)


    class Meta:
        model = User
        fields = ['username', 'password', 'requested_role']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['requested_role'].choices = [
            ('CITIZEN', 'Citizen'),
            ('OFFICER', 'Police Officer (Approval Required)'),
            ('INVESTIGATOR', 'Investigating Officer'),
            ('FORENSIC', 'Forensic Analyst'),
            ('JUDGE', 'Judge'),
            ('AUDITOR', 'Judicial Auditor'),
        ]

    def clean(self):
        cleaned_data = super().clean()
        role = cleaned_data.get('requested_role')

        if role == 'OFFICER':
            required_fields = [
                ('rank', 'Rank: Required for Police Officer'),
                ('badge_id', 'Badge ID: Required for Police Officer'),
                ('department', 'Department: Required for Police Officer'),
                ('reason_for_access', 'Reason for access: Required for Police Officer')
            ]
            for field_name, error_message in required_fields:
                if not cleaned_data.get(field_name):
                    self.add_error(field_name, error_message)

        # 🔐 VERIFIED ROLES REQUIRE PROOF
        if role == 'INVESTIGATOR':
            required = ['rank', 'jurisdiction', 'appointment_order', 'reason_for_access']
            for field in required:
                if not cleaned_data.get(field):
                    self.add_error(field, 'Required for verification')

         # 🧬 FORENSIC
        elif role == 'FORENSIC':
            required = ['lab_affiliation', 'forensic_license', 'jurisdiction', 'reason_for_access']

        # ⚖️ JUDGE
        elif role == 'JUDGE':
            required = ['judicial_id', 'court_name', 'jurisdiction']

        # 🧾 AUDITOR
        elif role == 'AUDITOR':
            required = ['authority_letter', 'jurisdiction']

        else:
            required = []

        for field in required:
            if not cleaned_data.get(field):
                self.add_error(field, 'This field is required for this role')

        return cleaned_data



    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])

        selected_role = self.cleaned_data.get('requested_role')

        # Default role
        user.role = 'CITIZEN'
        user.requested_role = (
            selected_role if selected_role != 'CITIZEN' else None
        )

        if commit:
            user.save()

            # 👮 Officer profile
            if selected_role == 'OFFICER':
                if not hasattr(user, 'officer_profile'):
                    OfficerProfile.objects.create(
                        user=user,
                        rank=self.cleaned_data['rank'],
                        badge_id=self.cleaned_data['badge_id'],
                    department=self.cleaned_data['department'],
                    reason_for_access=self.cleaned_data['reason_for_access']
                )

            # 🔐 Investigator 
            elif selected_role == 'INVESTIGATOR':
                if not hasattr(user, 'role_verification'):
                    RoleVerification.objects.create(
                    user=user,
                    role=selected_role,
                    rank=self.cleaned_data['rank'],
                    jurisdiction=self.cleaned_data['jurisdiction'],
                    appointment_order=self.cleaned_data['appointment_order'],
                    reason_for_access=self.cleaned_data['reason_for_access']
                )


            elif selected_role == 'FORENSIC ANALYST':
                if not hasattr(user, 'role_verification'):
                    forensic_license = forms.FileField(required=False)
                    lab_name = forms.CharField(required=False)
                    RoleVerification.objects.create(
                        user=user,
                        role=selected_role,
                        forensic_license=forensic_license,
                        lab_name=lab_name
                    )
            elif selected_role == 'JUDGE':
                if not hasattr(user, 'role_verification'):
                    judicial_id = forms.CharField(required=False)
                    court_name = forms.CharField(required=False)
                    RoleVerification.objects.create(
                        user=user,
                        role=selected_role,
                        judicial_id=judicial_id,
                        court_name=court_name
                    )

            elif selected_role == 'AUDITOR':    
                if not hasattr(user, 'role_verification'):
                    authority_letter = forms.FileField(required=False)
                    RoleVerification.objects.create(
                        user=user,
                        role=selected_role,
                        authority_letter=authority_letter
                    )


        return user



class LoginForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput)

    def clean(self):
        cleaned_data = super().clean()
        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        try:
            user = User.objects.get(username=username)
            if not user.check_password(password):
                raise forms.ValidationError("Invalid username or password")
            self.user = user
        except User.DoesNotExist:
            raise forms.ValidationError("Invalid username or password")

    def get_user(self):
        return self.user    